USDT / USD₮0 Wallet — Arbitrum One

Recommended use:
1. Download this ZIP from GitHub.
2. Extract it locally.
3. Verify index.html against SHA256SUMS.txt.
4. For wallet generation, recovery, private-key import, or signing, open index.html locally.
5. For highest assurance, disconnect networking before handling a recovery phrase/private key.
6. Only connect an RPC when balance lookup, transaction preparation, or broadcasting is needed.

Do not enter a real recovery phrase/private key into an unverified online copy.
The source is public so you can inspect it before use.
